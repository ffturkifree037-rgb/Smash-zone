SMASH ZONE - النسخة النهائية التجريبية
1) ارفع index.html إلى مستودع GitHub نفسه.
2) Settings > Pages > Deploy from a branch > main > /(root) > Save.
3) افتح رابط GitHub Pages بعد النشر.
