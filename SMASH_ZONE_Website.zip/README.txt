SMASH ZONE - Web
افتح index.html في المتصفح لمعاينة الموقع.
لجعله رابطًا عامًا، ارفع index.html إلى استضافة مواقع ثابتة مثل GitHub Pages.
GitHub Pages يعتمد على ملفات HTML/CSS/JS ثابتة ويستطيع نشرها من مستودع GitHub.
